package com.example.spring.controller;

import com.example.spring.model.Employee;
import com.example.spring.repository.EmployeeCrudRepository;
import com.example.spring.service.EmployeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("employee")
public class EmployeeController {

    private final EmployeeService employeeService;
    private final EmployeeCrudRepository repository;
    
    @Autowired
    public EmployeeController(EmployeeService employeeService, EmployeeCrudRepository repository) {
        this.employeeService = employeeService;
        this.repository = repository;
    }

    @GetMapping("/all")
    public List<Employee> all() {
        return employeeService.getEmployees();
    }
    
    @GetMapping("/{id}")
    public Optional<Employee> find(@PathVariable String id) {
        return repository.findById(id);
    }
    
    @PutMapping("/update")
    public Employee update(@RequestBody Employee e) {
        return repository.save(e);
    }
    
    @PostMapping("/create")
    public Employee create(@RequestBody Employee e) {
        return repository.save(e);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable String id) {
        repository.deleteById(id);
        return ResponseEntity.ok().body("deleted!");
    }
    
}
