package com.example.spring.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LogServiceAspect {
	
	private static final Logger LOG = LoggerFactory.getLogger(LogServiceAspect.class);
	
	@Around("execution(* com.example.spring.service.EmployeeService.*(..))")
	public Object aroundLog(ProceedingJoinPoint jp) throws Throwable {
		LOG.info("Executing method:" + jp.getSignature());
		Object obj = jp.proceed();
		LOG.info("Executed method: " + jp.getSignature());
		return obj;
	}

}
