package com.example.spring.dao;

import java.util.List;

import com.example.spring.model.Employee;

public interface EmployeeDao {

    List<Employee> getEmployeeList();
}
