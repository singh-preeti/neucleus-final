package com.example.spring.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.spring.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	private final JdbcTemplate jdbcTemplate;

	@Autowired
	public EmployeeDaoImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
    public List<Employee> getEmployeeList() {
        return jdbcTemplate.query("select * from employees", (rs, i) -> 
        	new Employee(rs.getString(1), rs.getString(2), rs.getString(3))
        );
    }

}
